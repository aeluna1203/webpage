AELUNA HAPPY CASTE — PROFESSIONAL WEBSITE

Preview:
1. Extract the ZIP.
2. Open index.html in Chrome or Edge.
3. The logo is embedded directly in index.html, so it will not appear broken if you upload only the HTML file.

Publish using GitHub Pages:
1. Create a public repository on GitHub.
2. Upload index.html to the repository root.
3. Open Settings > Pages.
4. Select Deploy from a branch, branch main, folder /(root), then Save.
5. Wait for GitHub Pages to publish and use the URL shown there.

Business details:
Aeluna Happy Caste
Chennai, Tamil Nadu, India
Phone / WhatsApp: +91 93458 51474
Email: aelunahappycast@gmail.com

The enquiry form opens the visitor's email app. It does not store form submissions on a server.
